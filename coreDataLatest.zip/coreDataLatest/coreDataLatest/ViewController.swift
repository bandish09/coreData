//
//  ViewController.swift
//  coreDataLatest
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        insertData()
//        updateData()
//        deleteData()
//        fetchData()
    }

    
    func deleteData(){
        guard let objAppdelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let manageContext = objAppdelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Tbl_student")
//        fetchRequest.predicate = NSPredicate(format: "name = %@", "Unknown")
        do {
            let result = try manageContext.fetch(fetchRequest)
            if result.count > 0{
                for row in result as! [NSManagedObject]{
                    manageContext.delete(row)
                }
                do {
                    try manageContext.save()
                } catch {
                    print("failed: saving after delete the records")
                }
            }
        } catch  {
            print("failed: delete records")
        }
        
        
    }
    
    func updateData(){
        guard let objAppdelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let manageContext = objAppdelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Tbl_student")
        fetchRequest.predicate = NSPredicate(format: "city = %@", "5 botad")
        do {
            let result = try manageContext.fetch(fetchRequest)
            if result.count > 0{
                for row in result as! [NSManagedObject]{
                    let objStudent = row as? Tbl_student
                    objStudent?.name = "Unknown"
                }
                do {
                    try manageContext.save()
                } catch  {
                    print("failed: update and save context")
                }
            }
        } catch  {
            print("failed: update record")
        }
    }
    
    func insertData(){
        deleteData()
        guard let objAppdelegate = UIApplication.shared.delegate as? AppDelegate else {
                    return
        }
        let objManageContext = objAppdelegate.persistentContainer.viewContext
        
        for i in 1...5
        {
            let objStudent = Tbl_student(context: objManageContext)
            objStudent.name = "\(i) bandish"
            objStudent.city = "\(i) botad"
            
            //Create passport record
            let objpassport = Tbl_passport(context: objManageContext)
            objpassport.number = 98966

            //Set passport id in student(one to one)
            objStudent.passportID = objpassport
            
            //create task for student
            var taskArray = [Tbl_task]()
            for i in 0...2{
                //creating task record
                let objTasks = Tbl_task(context: objManageContext)
                objTasks.name = "\(i) task"
                objTasks.detail = "\(i) detail"
                taskArray.append(objTasks)
                //objStudent.addToTaskIDS(objTasks)
            }
            objStudent.taskIDS = NSSet(array: taskArray)
        }
        do {
            try objManageContext.save()
        } catch let error as NSError {
            print("error on create::: \(error.userInfo)")
        }
    }
    
    func fetchData(){
        guard let objAppdelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let objManageContext = objAppdelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Tbl_student")
//         you can fetch records based on condition also like
//         fetchRequest.predicate = NSPredicate(format: "city = %@", "3 botad")
//         fetchRequest.fetchLimit = 1
         fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]

        do{
            let result = try objManageContext.fetch(fetchRequest)
            for row in result as! [NSManagedObject]{
                let student = row as? Tbl_student
                print("studenent \(String(describing: student?.name))")
                print("passport  \(String(describing: student?.passportID))")
                for row in student?.taskIDS ?? [] {
                    let objTask = row as? Tbl_task
                    print("task name: \(String(describing: objTask?.name))")
                }
            }
        } catch let error as NSError {
            print("error on create::: \(error.userInfo)")
        }
        
    }

}

